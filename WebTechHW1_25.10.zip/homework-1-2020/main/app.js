const distance = (a, b) => {
	if(typeof(a)!="string"||typeof(b)!="string")
	{
		throw new Error('InvalidType');
	}
	else
	{
	const levArray=Array(b.length+1).fill(null).map(()=>
	Array(a.length+1).fill(null));
	for(let i=0;i<=a.length;i++){
		levArray[0][i]=i;
	}
	for(let j=0;j<=b.length;j++){
		levArray[j][0]=j;
	}
	for (let j=1;j<=b.length;j++) {
		for (let i=1;i<=a.length;i++) {
		   const aux=a[i-1]===b[j-1] ? 0 : 1;
		   levArray[j][i] = Math.min(
			  levArray[j][i-1]+1,
			  levArray[j-1][i]+1,
			  levArray[j-1][i-1]+aux,
		   );
		}
	 }
	return levArray[b.length][a.length];
	} 
}
	


module.exports.distance = distance